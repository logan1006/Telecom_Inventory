package com.tcs.BSL;

public class SelectUser {
	public static int giveFunction(String users)
	{
		if(users.equals("Admin"))
		{
			return 1;
		}
		else if(users.equals("Retailer"))
		{
			return 2;
		}
		else if(users.equals("Inventory Manager"))
		{
			return 3;
		}
		return 0;
	}

}
