package com.tcs.BSL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.tcs.DAO.RetailerDAO;

public class UntagBSL {
	static Connection con;
	static PreparedStatement pst;
	
	public static int Untag(String pmId,String ruid)
	{
		int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			
			pst=con.prepareStatement("delete from rtl_productmodel_tag_tbl where PRODUCTID=? and USERID=?");
			pst.setString(1,pmId);
			pst.setString(2,ruid);
			
			//pst.setString(5,rid);
			
			result=pst.executeUpdate();
			
			
			
		}catch(SQLException e){System.out.print(e);}
		return result;
	}

}
