package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tcs.BSL.*;

import com.tcs.MODEL.*;

/**
 * Servlet implementation class UpdateController
 */
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
	/*PrintWriter p=response.getWriter();
		 response.setContentType("text/html");
		 
		 UpdateModel umodel=new UpdateModel();
		
		 umodel.setRuid(request.getParameter("ruid"));
	
		 
		 int res=UpdateBSL.UpdateData(umodel.getRuid());
		 
		 if(res>0)
		 {
				RequestDispatcher redisp=getServletContext().getRequestDispatcher("/Update_RetDisp.jsp");
			redisp.forward(request, response);
			}

		 else
			 p.print("<h1> UserId not searched successfully</h1>");*/
		
		
		PrintWriter p=response.getWriter();
		 HttpSession session = request.getSession(true);
		response.setContentType("text/html");
		
//Servlet is calling Bean to handle the data within its variables using setter() methods

	UpdateModel prmobean =new UpdateModel();
	
	prmobean.setRname(request.getParameter("rname"));
	prmobean.setRloc(request.getParameter("rloc"));
	prmobean.setRlno(request.getParameter("rlno"));
	
	prmobean.setRuid(request.getParameter("ruid"));
	prmobean.setRid(request.getParameter("rid"));
	
	//Data from Bean using setter method
	int res=Update1BSL.Search(prmobean.getRname(),prmobean.getRloc(),prmobean.getRlno(),prmobean.getRuid(),prmobean.getRid());
	ArrayList <DisplayMODEL> orderqty= new ArrayList<DisplayMODEL>();
	
	orderqty=UpdateBSL.UpdateData(request.getParameter("ruid"));

	System.out.print("res"+res);
request.setAttribute("OrderQty", orderqty);
	if(res>0){
		
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/updateDisp.jsp");
		rd.forward(request,response);
	}
	/*else
	{
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/userNotfound.jsp");
		rd.forward(request,response);

       
	}*/
	}



	}



