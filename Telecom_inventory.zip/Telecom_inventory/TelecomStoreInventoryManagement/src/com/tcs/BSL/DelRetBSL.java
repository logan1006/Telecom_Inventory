package com.tcs.BSL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.tcs.DAO.RetailerDAO;
public class DelRetBSL {

	static Connection con;
	static PreparedStatement pst;
	
	public static int Delete(String ruid)
	{
		int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			
			pst=con.prepareStatement("delete from rtl_info_tbl where USER_ID=?");
		//	pst.setString(1,pmId);
			pst.setString(1,ruid);
			
			//pst.setString(5,rid);
			
			result=pst.executeUpdate();
			
			
			
		}catch(SQLException e){System.out.print(e);}
		return result;
}
}
