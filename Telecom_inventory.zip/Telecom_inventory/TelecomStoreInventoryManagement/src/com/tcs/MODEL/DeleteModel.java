package com.tcs.MODEL;

public class DeleteModel {
	String ruid;

	public String getRuid() {
		return ruid;
	}

	public void setRuid(String ruid) {
		this.ruid = ruid;
	}
	

}