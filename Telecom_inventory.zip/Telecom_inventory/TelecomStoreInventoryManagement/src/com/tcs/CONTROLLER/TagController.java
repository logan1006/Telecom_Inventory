package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.servlet.RequestDispatcher;
import com.tcs.BSL.*;
import com.tcs.MODEL.*;

import java.util.ArrayList;

/**
 * Servlet implementation class TagController
 */
public class TagController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TagController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter p=response.getWriter();
		//System.out.print(request.getAtt("ruid"));
		 HttpSession session = request.getSession(true);
		 session.setAttribute("ruid",request.getParameter("ruid"));
		 System.out.println("Retailer:"+session.getAttribute("ruid"));
		response.setContentType("text/html");
		ArrayList <TagMODEL1> orderqty= new ArrayList<TagMODEL1>();
		
		orderqty=TagSearchBSL.SearchData(request.getParameter("ruid"));
	// System.out.print(orderqty);
		if(orderqty.isEmpty())
		{
			RequestDispatcher redisp=getServletContext().getRequestDispatcher("/userNotfound.jsp");
			redisp.forward(request, response);
		}
		else
		{//System.out.print(orderqty);
		request.setAttribute("TagDetails", orderqty);
		RequestDispatcher redisp=getServletContext().getRequestDispatcher("/TagController1");
		redisp.forward(request, response);
		}
	

}
	}
