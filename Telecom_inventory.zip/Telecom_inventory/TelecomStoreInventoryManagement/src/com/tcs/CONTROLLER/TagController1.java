package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.RequestDispatcher;
import com.tcs.BSL.*;
import com.tcs.MODEL.*;

import java.util.ArrayList;
/**
 * Servlet implementation class TagController1
 */
public class TagController1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TagController1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter p=response.getWriter();
		response.setContentType("text/html");
		ArrayList<AddProModBean> proMod=new ArrayList<AddProModBean>();
		
	proMod=ViewProModBSL.displayAllOrder();
	
	
	
		request.setAttribute("TagDetails", proMod);
		RequestDispatcher redisp=getServletContext().getRequestDispatcher("/tagItemsDisp.jsp");
		redisp.forward(request, response);
	}

}
