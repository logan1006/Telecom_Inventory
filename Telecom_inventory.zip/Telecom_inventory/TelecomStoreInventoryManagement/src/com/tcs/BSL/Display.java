package com.tcs.BSL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.tcs.DAO.RetailerDAO;
import com.tcs.MODEL.*;

public class  Display {
	static ArrayList <DisplayMODEL> al=new ArrayList<DisplayMODEL>();
	static Connection con;
	static ResultSet rs;
	static PreparedStatement pst;
	static 	DisplayMODEL  od;
	public static ArrayList DisplayAllDetails()
		
		{
		try
		{
			con=RetailerDAO.dbConnect();
			String strqry="Select * from rtl_info_tbl";
			pst=con.prepareStatement(strqry);
			rs=pst.executeQuery();
			while(rs.next())
			{
	
  od=new DisplayMODEL(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5));
	 al.add(od);
		 
			}
			
			
			
			/*for(int i=0;i<al.size();i++)
			{
				System.out.print("Name " +al.get(i).getRname());
			}
			
			*/
			
		}catch(Exception e)
		{
			System.out.print("BSL Error"+e);
			
		}
		
		return al;
		
	}
}
