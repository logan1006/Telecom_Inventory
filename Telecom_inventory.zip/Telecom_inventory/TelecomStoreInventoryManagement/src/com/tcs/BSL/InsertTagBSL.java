package com.tcs.BSL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;



import com.tcs.DAO.RetailerDAO;

public class InsertTagBSL {

	static Connection con;
	static PreparedStatement pst;
	//static  int rid=0;
	public static int InsertData(String ruid, String [] pmId)
	{
		int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			for(int i=0;i<pmId.length;i++)
			{
			pst=con.prepareStatement("insert into rtl_productmodel_tag_tbl values(?,?)");
			pst.setString(1,ruid);
			pst.setString(2,pmId[i]);
			result=pst.executeUpdate();
			}
			
			
			
			
			
			
		}catch(SQLException e){}
		return result;
	}
}



