
package com.tcs.BSL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



import com.tcs.DAO.RetailerDAO;
import com.tcs.MODEL.*;

public class DispTagBSL {
	static ArrayList <TagMODEL> al=new ArrayList<TagMODEL>();
	static Connection con;
	static ResultSet rs;
	static PreparedStatement pst;
	static 	TagMODEL  od;
	public static ArrayList DisplayAllDetails()
		
		{
		try
		{
			con=RetailerDAO.dbConnect();
			String strqry="Select * from rtl_productmodel_tag_tbl";
			pst=con.prepareStatement(strqry);
			rs=pst.executeQuery();
			while(rs.next())
			{
	
  od=new TagMODEL(rs.getString(1), rs.getString(2));
	 al.add(od);
		 
			}
			
			
			
		}catch(Exception e)
		{
			System.out.print("BSL Error"+e);
			
		}
		
		return al;
		
	}
}

