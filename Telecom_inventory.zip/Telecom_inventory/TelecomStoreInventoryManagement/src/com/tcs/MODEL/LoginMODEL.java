package com.tcs.MODEL;

public class LoginMODEL {
	String username;
	String passwd;
 String users;
	public LoginMODEL(String username, String passwd,String users) {
		//super();
		this.username = username;
		this.passwd = passwd;
		this.users=users;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getUsers() {
		return users;
	}
	public void setUsers(String users) {
		this.users = users;
	}
}
