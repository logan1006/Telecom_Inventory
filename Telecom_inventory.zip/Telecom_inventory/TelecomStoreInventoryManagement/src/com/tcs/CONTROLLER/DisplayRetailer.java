package com.tcs.CONTROLLER;

import com.tcs.MODEL.*;
import com.tcs.BSL.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class DisplayRetailer
 */
public class DisplayRetailer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayRetailer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		PrintWriter p=response.getWriter();
		response.setContentType("text/html");
		ArrayList<DisplayMODEL> alorder=new ArrayList<DisplayMODEL>();
		
		
		
		//System.out.print( "retId"+rid);
	alorder=Display.DisplayAllDetails();
	
	request.setAttribute("Retailer Details", alorder);
	RequestDispatcher redisp=getServletContext().getRequestDispatcher("/CheckDisplay.jsp");
	redisp.forward(request, response);

}
}
