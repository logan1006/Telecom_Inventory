package com.tcs.BSL;

import java.sql.*;
import java.util.*;

import com.tcs.DAO.*;
import com.tcs.MODEL.*;

public class LoginBSL {
	static ArrayList <LoginMODEL> al=new ArrayList<LoginMODEL>();
	static Connection con;
	static ResultSet rs;
	static PreparedStatement pst;
	static 	LoginMODEL od;
	public static int CheckLogin(String username,String passwd,String users)
	{
		
		try
		{
			con=RetailerDAO.dbConnect();
			String strqry="Select USERNAME,PASSWORD,ROLETAGGED from login_tbl";
			pst=con.prepareStatement(strqry);
			rs=pst.executeQuery();
			while(rs.next())
			{
	
				od=new LoginMODEL(rs.getString(1), rs.getString(2), rs.getString(3));
				al.add(od);
				if(rs.getString(1).equals(username)==true && rs.getString(2).equals(passwd)==true && rs.getString(3).equals(users)==true)
				{
					return 1;
				}
			
				
				
		 
			}
			
		}catch(Exception e)
		{
			System.out.print("BSL Error"+e);
			
		}
		
		return 0;
		
	}

}
