package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.BSL.*;
import com.tcs.MODEL.*;

/**
 * Servlet implementation class UntagController
 */
public class UntagController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UntagController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter p=response.getWriter();
		 response.setContentType("text/html");
		 
		TagMODEL dmodel=new TagMODEL();
		
		 dmodel.setPmId(request.getParameter("pmId"));
		 dmodel.setRuid(request.getParameter("ruid"));
		 
		
		 
		 int res=UntagBSL.Untag(request.getParameter("pmId"),request.getParameter("ruid"));
		 
		if(res>0)
		{
			RequestDispatcher redisp=getServletContext().getRequestDispatcher("/delete_display.jsp");
		redisp.forward(request, response);
		}
		 else
		 {
			 RequestDispatcher redisp=getServletContext().getRequestDispatcher("/Retailer_NotDel.jsp");
		redisp.forward(request, response);
	}
	}
}

