package com.tcs.BSL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;



import com.tcs.DAO.RetailerDAO;
public class RoleBSL {
	static Connection con;
	static PreparedStatement pst;
	//static  int rid=0;
	public static int InsertRoleDet(String userID,String username,String addr, String cname,String ename,String pname,String rolename)
	{
		int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			
			pst=con.prepareStatement("insert into login_tbl values(?,?,?,?,?,?,?)");
			pst.setString(1,userID);
			pst.setString(2,username);
			pst.setString(3,addr);
			pst.setString(4,cname);
			pst.setString(5,ename);
			pst.setString(6,pname);
			pst.setString(7,rolename);
			
			result=pst.executeUpdate();
			
			
			/*String str1=rlno;
			String str2=ruid;
			if(result>0)
			{
			 rid="ADD";
			}*/
/*		 if(result!=0)
			 rid=rid+1;
			*/
		}catch(SQLException e){}
		return result;
}
}
