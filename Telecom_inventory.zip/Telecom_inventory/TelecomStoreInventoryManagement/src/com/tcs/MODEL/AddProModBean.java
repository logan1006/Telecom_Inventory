package com.tcs.MODEL;

import java.sql.Date;

public class AddProModBean {
	String pmId;
	 String pmName;
	 String pmDesc;
	 String pmFeatu;
	 Double pmPrice;
	 Date date;
	 public AddProModBean(String pmId) {
		super();
		this.pmId = pmId;
	}
	int pmThreshold;
	public AddProModBean(String pmId, String pmName) {
		this.pmId = pmId;
		this.pmName = pmName;
	}
	public AddProModBean(String pmId, String pmName, String pmDesc,
			String pmFeatu, Double pmPrice, int pmThreshold) {
		super();
		this.pmId = pmId;
		this.pmName = pmName;
		this.pmDesc = pmDesc;
		this.pmFeatu = pmFeatu;
		this.pmPrice = pmPrice;
		this.pmThreshold = pmThreshold;
	}
	public String getPmId() {
		return pmId;
	}
	public void setPmId(String pmId) {
		this.pmId = pmId;
	}
	public String getPmName() {
		return pmName;
	}
	public void setPmName(String pmName) {
		this.pmName = pmName;
	}
	public String getPmDesc() {
		return pmDesc;
	}
	public void setPmDesc(String pmDesc) {
		this.pmDesc = pmDesc;
	}
	public String getPmFeatu() {
		return pmFeatu;
	}
	public void setPmFeatu(String pmFeatu) {
		this.pmFeatu = pmFeatu;
	}
	public Double getPmPrice() {
		return pmPrice;
	}
	public void setPmPrice(Double pmPrice) {
		this.pmPrice = pmPrice;
	}
	public int getPmThreshold() {
		return pmThreshold;
	}
	public void setPmThreshold(int pmThreshold) {
		this.pmThreshold = pmThreshold;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

}
