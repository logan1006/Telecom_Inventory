package com.tcs.BSL;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.DAO.RetailerDAO;
import com.tcs.MODEL.*;

public class TagProdBSL {

	static ArrayList <TagMODEL> al=new ArrayList<TagMODEL>();
	static Connection con;
	static ResultSet rs;
	static PreparedStatement pst;
	static TagMODEL  od;
	/*public static ArrayList<TagMODEL> DisplayAllDetails(String sel[])
		{
		try
		{
			con=RetailerDAO.dbConnect();
			String strqry="Select PRODUCTMODEL_ID from productmodel_info_tbl";
			pst=con.prepareStatement(strqry);
			rs=pst.executeQuery();
			while(rs.next())
			{
	
  od=new TagMODEL(rs.getString(1));
	 al.add(od);
		 
			}
			
			
			
			/*for(int i=0;i<al.size();i++)
			{
				System.out.print("Name " +al.get(i).getRname());
			}
			
		
			
		}catch(Exception e)
		{
			System.out.print("BSL Error"+e);
			
		}
		
		return al;
		
	}
	*/
	
	
	
	public TagMODEL DisplayAllDetails(String pmId)
	{
		//ArrayList<TagMODEL> items = new ArrayList<TagMODEL>(); //initialize a list
		//SQL string:
		String sql = "SELECT PRODUCTMODEL_ID FROM productmodel_info_tbl WHERE PRODUCTMODEL_ID='"+pmId+"'";
		//establish the database connection:
		 con =RetailerDAO.dbConnect();
		
		try
		{
			pst=con.prepareStatement(sql);
		rs=pst.executeQuery();
			if(rs.next())
			{
				
				String pmid = rs.getString(1);
				//String ruId = rs.getString(2);
				
				
				//initialize a Book bean object:
				TagMODEL i = new TagMODEL(pmid);
				
				//System.out.print("Retailer Id"+ ruid);
				//add the book bean object to the logical list:
				return i;
			}			
		}
		catch(Exception e)
		{
			System.out.print("BSL Error"+e);
			
		}
		
		return null;
	}
}
	

