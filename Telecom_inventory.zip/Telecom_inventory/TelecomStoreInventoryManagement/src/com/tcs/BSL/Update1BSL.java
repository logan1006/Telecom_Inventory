package com.tcs.BSL;


import java.sql.Connection;
import com.tcs.MODEL.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.DAO.RetailerDAO;
public class Update1BSL {
	static Connection con;
	static PreparedStatement pst1;
	//BSL is consisting the Business Logic function to insert the data into the database.
	public static int Search(String rname,String rloc,String rlno,String ruid,String rid)
	{
		int result=0;
		
		try
		{ 
			con=RetailerDAO.dbConnect();//To insert the data into a database Connection from DAO is called by BSL
			//Business Logic for Data Insert
			
			
			
			pst1=con.prepareStatement("Update rtl_info_tbl set Retailer_Name=?,Retailer_loc=?,Licence_No=?,RetailerID=? where User_Id=?");
		
			pst1.setString(1,rname);
			pst1.setString(2,rloc);
			pst1.setString(3,rlno);
			pst1.setString(5,ruid);
			pst1.setString(4,rid);
		
			
			result=pst1.executeUpdate();
			
		}
		catch(SQLException e){}
		System.out.println(result);
		return result;
	
	}
}
