package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.BSL.*;
import com.tcs.MODEL.*;

import java.util.ArrayList;




/**
 * Servlet implementation class InsertRoleController
 */
public class InsertRoleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertRoleController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter p=response.getWriter();
		 response.setContentType("text/html");
		 
		 
		 
		 
		 RoleMODEL dmodel=new RoleMODEL();
		 dmodel.setUserID(request.getParameter("userID"));
		 dmodel.setUsername(request.getParameter("username"));
		 dmodel.setAddr(request.getParameter("addr"));
		 dmodel.setCname(request.getParameter("cname"));
		 dmodel.setEname(request.getParameter("ename"));
		 dmodel.setPname(request.getParameter("pname"));
		 dmodel.setRolename(request.getParameter("rolename"));
		 
		 int res=RoleBSL.InsertRoleDet(dmodel.getUserID(), dmodel.getUsername(), dmodel.getAddr(), dmodel.getCname(),dmodel.getEname(), dmodel.getPname(), dmodel.getRolename());
		 

		 
			
			RequestDispatcher redisp=getServletContext().getRequestDispatcher("/admin.jsp");
			redisp.forward(request, response);
	}

}
