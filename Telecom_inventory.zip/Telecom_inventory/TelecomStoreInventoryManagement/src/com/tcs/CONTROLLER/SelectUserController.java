package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.BSL.*;
import com.tcs.MODEL.*;
/**
 * Servlet implementation class SelectUserController
 */
public class SelectUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectUserController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter p=response.getWriter();
		response.setContentType("text/html");
		RequestDispatcher redisp;
		String users1=request.getParameter("users"); 
		int res=SelectUser.giveFunction(users1);
		switch(res)
		{
		case 1:
			redisp=getServletContext().getRequestDispatcher("/LoginController");
			redisp.forward(request, response);
			break;
		case 2:
			redisp=getServletContext().getRequestDispatcher("/DeleteProModServlet");
			redisp.forward(request, response);
			break;
		case 3:
			redisp=getServletContext().getRequestDispatcher("/AddProduct.jsp");
			redisp.forward(request, response);
			break;
			default:
				p.print("Not Valid");
		}
	}

}
