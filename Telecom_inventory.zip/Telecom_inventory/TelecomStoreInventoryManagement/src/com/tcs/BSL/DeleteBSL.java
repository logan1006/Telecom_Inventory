package com.tcs.BSL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.tcs.DAO.RetailerDAO;

public class DeleteBSL {
	static Connection con;
	static PreparedStatement pst;
	
	public static int DeleteData(String ruid)
	{
		int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			
			pst=con.prepareStatement("select USERID from rtl_productmodel_tag_tbl where USERID=?");
			pst.setString(1,ruid);
			
			//pst.setString(5,rid);
			
			result=pst.executeUpdate();
			/*if(result==0)
			{
				pst=con.prepareStatement("delete USER_ID from rtl_info_tbl where USER_ID=?");
				pst.setString(1,ruid);
				result1=pst.executeUpdate();
			}*/
			
			
			
		}catch(SQLException e){System.out.print(e);}
		return result;
	}

}






