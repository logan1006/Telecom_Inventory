package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.BSL.*;
import com.tcs.MODEL.*;

/**
 * Servlet implementation class DeleteController
 */
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter p=response.getWriter();
		 response.setContentType("text/html");
		 
		 
		 
		 
		DeleteModel dmodel=new DeleteModel();
		
		 dmodel.setRuid(request.getParameter("ruid"));
		
		 
		 int res=DeleteBSL.DeleteData(request.getParameter("ruid"));
		 System.out.print(res);
		if(res==0)
		{
			RequestDispatcher redisp=getServletContext().getRequestDispatcher("/DelRetController");
		redisp.forward(request, response);
		}
		 else
		 {
			 RequestDispatcher redisp=getServletContext().getRequestDispatcher("/deletion_tag_unsuccess.jsp");
		redisp.forward(request, response);
		 }
	
		 
		
		//ArrayList<DeleteModel> alorder=new ArrayList<DeleteModel>();
			
		//alorder=Display.DisplayAllDetails();
				//request.setAttribute("Deleted" , alorder);
		//RequestDispatcher redisp=getServletContext().getRequestDispatcher("/delete_display.jsp");
		//redisp.forward(request, response);
		}
	

}
