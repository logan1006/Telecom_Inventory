package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.BSL.*;
import com.tcs.MODEL.*;

/**
 * Servlet implementation class AllTagRetDispController
 */
public class AllTagRetDispController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllTagRetDispController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter p=response.getWriter();
		response.setContentType("text/html");
		ArrayList<TagMODEL> alorder=new ArrayList<TagMODEL>();
		
		
		
		//System.out.print( "retId"+rid);
	alorder=AllTagDispBSL.DisplayAllDetails();
	
	request.setAttribute("Retailer Tagged Details", alorder);
	RequestDispatcher redisp=getServletContext().getRequestDispatcher("/allTagRet.jsp");
	redisp.forward(request, response);
	}

}
