package com.tcs.CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tcs.BSL.Display;
import com.tcs.BSL.RetailerBSL;
import com.tcs.MODEL.DisplayMODEL;
import com.tcs.MODEL.RetailerMODEL;

/**
 * Servlet implementation class RetailerInsertController
 */
public class RetailerInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RetailerInsertController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  
		 PrintWriter p=response.getWriter();
		 response.setContentType("text/html");
		 
		 
		 
		 
		 RetailerMODEL dmodel=new RetailerMODEL();
		 dmodel.setRname(request.getParameter("rname"));
		 dmodel.setRloc(request.getParameter("rloc"));
		 dmodel.setRlno(request.getParameter("rlno"));
		 dmodel.setRuid(request.getParameter("ruid"));
		 dmodel.setRid(request.getParameter("rid"));
		 
		 int res=RetailerBSL.InsertData(dmodel.getRname(), dmodel.getRloc(), dmodel.getRlno(), dmodel.getRuid(),dmodel.getRid());
		 

		 
			
			RequestDispatcher redisp=getServletContext().getRequestDispatcher("/DisplayRetailer");
			redisp.forward(request, response);

	/*if(res>0)
		{ p.print("<h1> Retailer details entered successfully</h1>");
		 
			
		
			p.print("Retailer id:" +al.get(i));
			}
		 else
			 p.print("<h1> Retailer details not entered successfully</h1>");
	
		 */}

}
