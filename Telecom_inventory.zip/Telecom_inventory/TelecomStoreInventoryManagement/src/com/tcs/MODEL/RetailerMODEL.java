package com.tcs.MODEL;

public class RetailerMODEL {

	String rname;
	String rloc;
	String rlno;
	String ruid;
	String rid;
	
	
	public String getRname() {
		return rname;
	}
	
	public void setRname(String rname){
		this.rname=rname;
	}
	
	
	
	public String getRloc() {
		return rloc;
	}
	
	public void setRloc(String rloc){
		this.rloc=rloc;
	}
	
	
	
	public String getRlno() {
		return rlno;
	}
	
	public void setRlno(String rlno){
		this.rlno=rlno;
	}
	
	
	
	
	public String getRuid() {
		return ruid;
	}
	
	public void setRuid(String ruid){
		this.ruid=ruid;
	}
	
	
	
	
	public String getRid() {
		return rid;
	}
	
	public void setRid(String rid){
		this.rid=rid;
	}
	
}
