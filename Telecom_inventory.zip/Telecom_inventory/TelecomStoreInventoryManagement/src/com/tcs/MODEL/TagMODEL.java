package com.tcs.MODEL;

public class TagMODEL {
	
	String ruid;
	String pmId;
	public TagMODEL()
	{
		
	}
	public String getRuid() {
		return ruid;
	}
	public void setRuid(String ruid) {
		this.ruid = ruid;
	}
	public String getPmId() {
		return pmId;
	}
	public void setPmId(String pmId) {
		this.pmId = pmId;
	}
	public TagMODEL( String pmId){
		//super();
		
		this.pmId = pmId;
	}
	public TagMODEL(String ruid, String pmId) {
		//super();
		this.ruid = ruid;
		this.pmId = pmId;
	}
	

}
