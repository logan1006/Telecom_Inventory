package com.tcs.BSL;

import java.sql.*;
import java.util.*;

import com.tcs.DAO.RetailerDAO;
import com.tcs.MODEL.*;

public class ViewProModBSL {
	static ArrayList <AddProModBean> vpm=new ArrayList<AddProModBean>();
	static Connection con;
	static ResultSet rs;
	static PreparedStatement pst;
	static 	AddProModBean pm;
	public static ArrayList displayAllOrder()
	{

		try
		{
			con=RetailerDAO.dbConnect();
			String strqry="Select  * from ProductModel_info_tbl";
			pst=con.prepareStatement(strqry);
			rs=pst.executeQuery();
			while(rs.next())
			{
	
pm=new AddProModBean(rs.getString(1), rs.getString(2));
	 vpm.add(pm);
	
			}
			 rs.close();
		}catch(Exception e)
		{
			System.out.print("BSL Error"+e);
			
		}
		
		return vpm;
		
	}

}
