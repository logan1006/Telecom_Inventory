package com.tcs.BSL;


import java.sql.Connection;
import com.tcs.MODEL.*;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.DAO.RetailerDAO;


public class TagSearchBSL {
	static ArrayList <TagMODEL1> al=new ArrayList<TagMODEL1>();
	static Connection con;
	static PreparedStatement pst;
	static TagMODEL1 pm;
	static ResultSet rs;
	public static ArrayList<TagMODEL1> SearchData(String ruid)
	{
		//int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			//System.out.print(ruid);
			String strqry="select User_ID from RTL_INFO_TBL where User_ID=?";
			pst=con.prepareStatement(strqry);
			//pst.setString(1,rname);
			//pst.setString(2,rloc);
			//pst.setString(3,rlno);
			pst.setString(1,ruid);
			
			//pst.setString(5,rid);
			
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				 
				pm=new TagMODEL1(rs.getString(1));
				 al.add(pm);
			}
			
		}catch(SQLException e){}
		//System.out.print(al);
		return al;
	}


}
