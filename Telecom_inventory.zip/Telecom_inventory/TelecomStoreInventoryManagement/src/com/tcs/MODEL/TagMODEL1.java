package com.tcs.MODEL;

public class TagMODEL1 {

	String ruid;

	public TagMODEL1(String ruid) {
		//super();
		this.ruid = ruid;
	}

	public String getRuid() {
		return ruid;
	}

	public void setRuid(String ruid) {
		this.ruid = ruid;
	}
}
