package com.tcs.BSL;

import java.sql.Connection;
import com.tcs.MODEL.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.tcs.DAO.RetailerDAO;

public class UpdateBSL {
	static ArrayList <DisplayMODEL> al=new ArrayList<DisplayMODEL>();
	static Connection con;
	static PreparedStatement pst;
	static DisplayMODEL pm;
	static ResultSet rs;
	public static ArrayList<DisplayMODEL> UpdateData(String ruid)
	{
		//int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			
			String strqry="select * from RTL_INFO_TBL where User_ID=?";
			pst=con.prepareStatement(strqry);
			//pst.setString(1,rname);
			//pst.setString(2,rloc);
			//pst.setString(3,rlno);
			pst.setString(1,ruid);
			
			//pst.setString(5,rid);
			
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				 
				pm=new DisplayMODEL(rs.getString(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				 al.add(pm);
			}
			
		}catch(SQLException e){}
		return al;
	}

}



