package com.tcs.BSL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;



import com.tcs.DAO.RetailerDAO;

public class RetailerBSL {
	
	static Connection con;
	static PreparedStatement pst;
	//static  int rid=0;
	public static int InsertData(String rname,String rloc,String rlno, String ruid,String rid)
	{
		int result=0;
		
		try
		{
			con=RetailerDAO.dbConnect();
			
			pst=con.prepareStatement("insert into rtl_info_tbl values(?,?,?,?,?)");
			pst.setString(1,rname);
			pst.setString(2,rloc);
			pst.setString(3,rlno);
			pst.setString(4,ruid);
			rid=rlno+ruid;
			pst.setString(5,rid);
			
			result=pst.executeUpdate();
			
			
			//String str1=rlno;
			//String str2=ruid;
			
			
			if(result!=0)
			{
				System.out.println("RetailerId:" +rid);
			}
			/*if(result>0)
			{
			 rid="ADD";
			}*/
/*		 if(result!=0)
			 rid=rid+1;
			*/
		}catch(SQLException e){}
		return result;
	}
/*public static String getValue()
{
	return rid;
}*/
	
	
	
}
