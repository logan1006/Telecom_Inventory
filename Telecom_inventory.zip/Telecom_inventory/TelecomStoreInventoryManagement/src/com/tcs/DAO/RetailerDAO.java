package com.tcs.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class RetailerDAO {
	
	static Connection con=null;
	
	public static Connection dbConnect()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException es)
		{
			System.out.print(es.toString());
		}
		try
		{
			con=DriverManager.getConnection("jdbc:oracle:thin:@172.16.2.80:1521:ORCL","TEAMB","TEAMB");
			
		}catch(SQLException e)
		{
			
		}
		return con;
	          }

}
